CREATE DATABASE IF NOT EXISTS sklep_db DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci;
USE sklep_db;

CREATE TABLE IF NOT EXISTS administratorzy (
  id INT(11) NOT NULL AUTO_INCREMENT,
  login VARCHAR(50) NOT NULL,
  haslo VARCHAR(255) NOT NULL,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO administratorzy (id, login, haslo) VALUES (1, 'admin', 'admin123');

CREATE TABLE IF NOT EXISTS produkty (
  id INT(11) NOT NULL AUTO_INCREMENT,
  nazwa VARCHAR(100) NOT NULL,
  opis TEXT DEFAULT NULL,
  cena DECIMAL(10,2) NOT NULL,
  ilosc INT(11) NOT NULL DEFAULT 0,
  zdjecie_url VARCHAR(255) DEFAULT NULL,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO produkty (id, nazwa, opis, cena, ilosc, zdjecie_url) VALUES
(1, 'Myszka Bezprzewodowa V2', 'Ergonomiczna mysz dla graczy.', 129.99, 50, 'https://images.unsplash.com/photo-1527814050087-3793815479ea?w=800'),
(2, 'Klawiatura Mechaniczna', 'Klawiatura dla programistów na MX Red.', 299.00, 15, 'https://images.unsplash.com/photo-1595225476474-87563907a212?w=800'),
(3, 'Monitor UHD 4K 27"', 'Matryca IPS 144hz.', 1499.00, 5, 'https://images.unsplash.com/photo-1527443154391-507e9dc6c5cc?w=800');

CREATE TABLE IF NOT EXISTS klienci (
  id INT(11) NOT NULL AUTO_INCREMENT,
  imie VARCHAR(50) NOT NULL,
  nazwisko VARCHAR(50) NOT NULL,
  email VARCHAR(100) NOT NULL,
  telefon VARCHAR(20) DEFAULT NULL,
  adres TEXT DEFAULT NULL,
  PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO klienci (id, imie, nazwisko, email, telefon, adres) VALUES
(1, 'Jan', 'Kowalski', 'jan.kowal@example.com', '123456789', 'ul. Długa 5, Warszawa'),
(2, 'Anna', 'Nowak', 'anna.nowak@example.com', '987654321', 'ul. Krótka 1, Kraków');

CREATE TABLE IF NOT EXISTS zamowienia (
  id INT(11) NOT NULL AUTO_INCREMENT,
  klient_id INT(11) NOT NULL,
  produkt_id INT(11) NOT NULL,
  ilosc INT(11) NOT NULL DEFAULT 1,
  kwota DECIMAL(10,2) NOT NULL,
  status ENUM('nowe', 'w trakcie', 'wysłane', 'zakończone', 'anulowane') NOT NULL DEFAULT 'nowe',
  data_zamowienia DATETIME DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  FOREIGN KEY (klient_id) REFERENCES klienci(id) ON DELETE CASCADE,
  FOREIGN KEY (produkt_id) REFERENCES produkty(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO zamowienia (id, klient_id, produkt_id, ilosc, kwota, status) VALUES
(1, 1, 1, 2, 259.98, 'zakończone'),
(2, 2, 3, 1, 1499.00, 'w trakcie');
