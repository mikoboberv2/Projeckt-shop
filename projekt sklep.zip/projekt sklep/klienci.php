<?php
require_once 'config.php';
sprawdzLogowanie();

$action = $_GET['action'] ?? 'lista';
$blad = '';

// ── AKCJE PRZEKIEROWANIA ───────────────────────────────────────────────────

if ($action === 'usun' && isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id = (int)$_GET['id'];
    $stmt = $conn->prepare("DELETE FROM klienci WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute()
        ? header("Location: klienci.php?msg=usunieto")
        : die("Błąd podczas usuwania: " . $conn->error);
    $stmt->close();
    exit;
}

if ($action === 'pokaz' && isset($_GET['id']) && is_numeric($_GET['id'])) {
    if (!isset($_SESSION['pokazane_id'])) $_SESSION['pokazane_id'] = [];
    $id = (int)$_GET['id'];
    if (in_array($id, $_SESSION['pokazane_id'])) {
        $_SESSION['pokazane_id'] = array_diff($_SESSION['pokazane_id'], [$id]);
    } else {
        $_SESSION['pokazane_id'][] = $id;
    }
    header("Location: klienci.php");
    exit;
}

// ── FORMULARZ DODAJ / EDYTUJ ───────────────────────────────────────────────

$klient = null;
if (in_array($action, ['dodaj', 'edytuj'])) {
    if ($action === 'edytuj') {
        if (!isset($_GET['id']) || !is_numeric($_GET['id'])) { header("Location: klienci.php"); exit; }
        $id = (int)$_GET['id'];
        $stmt = $conn->prepare("SELECT * FROM klienci WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows === 0) { header("Location: klienci.php"); exit; }
        $klient = $result->fetch_assoc();
        $stmt->close();
    }

    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        $imie    = trim($_POST['imie']);
        $nazwisko = trim($_POST['nazwisko']);
        $email   = trim($_POST['email']);
        $telefon = trim($_POST['telefon']);
        $adres   = trim($_POST['adres']);

        if (!empty($imie) && !empty($nazwisko) && filter_var($email, FILTER_VALIDATE_EMAIL)) {
            $imie_enc    = szyfrujDane($imie);
            $nazwisko_enc = szyfrujDane($nazwisko);
            $email_enc   = szyfrujDane($email);
            $telefon_enc = szyfrujDane($telefon);
            $adres_enc   = szyfrujDane($adres);

            if ($action === 'dodaj') {
                $stmt = $conn->prepare("INSERT INTO klienci (imie, nazwisko, email, telefon, adres) VALUES (?, ?, ?, ?, ?)");
                $stmt->bind_param("sssss", $imie_enc, $nazwisko_enc, $email_enc, $telefon_enc, $adres_enc);
                $redirect = "klienci.php?msg=dodano";
            } else {
                $stmt = $conn->prepare("UPDATE klienci SET imie=?, nazwisko=?, email=?, telefon=?, adres=? WHERE id=?");
                $stmt->bind_param("sssssi", $imie_enc, $nazwisko_enc, $email_enc, $telefon_enc, $adres_enc, $id);
                $redirect = "klienci.php?msg=edytowano";
            }
            if ($stmt->execute()) {
                $stmt->close();
                header("Location: $redirect");
                exit;
            } else {
                $blad = "Błąd bazy danych: " . $conn->error;
            }
            $stmt->close();
        } else {
            $blad = "Podaj poprawne imię, nazwisko oraz prawidłowy adres email.";
        }
    }
}

// ── LISTA KLIENTÓW ─────────────────────────────────────────────────────────

if ($action === 'lista') {
    $result = $conn->query("SELECT * FROM klienci ORDER BY id DESC");
}
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>
        <?= $action === 'dodaj' ? 'Dodaj klienta' : ($action === 'edytuj' ? 'Edytuj klienta' : 'Klienci - Panel Administracyjny') ?>
    </title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
<?php renderNeonBg(); ?>
<div class="container">
    <?php renderNav('klienci'); ?>

<?php if ($action === 'lista'): ?>

    <div class="topbar">
        <h2>Klienci sklepu</h2>
        <div class="topbar-actions">
            <a href="klienci.php?action=dodaj" class="btn btn-success">+ Dodaj klienta</a>
            <a href="login.php?action=logout" class="btn btn-outline">Wyloguj się</a>
        </div>
    </div>

    <div class="card">
        <?php if (isset($_GET['msg'])): ?>
            <?php if ($_GET['msg'] === 'dodano'): ?>
                <div class="alert alert-success">Klient został pomyślnie dodany!</div>
            <?php elseif ($_GET['msg'] === 'edytowano'): ?>
                <div class="alert alert-success">Zmiany zostały zapisane!</div>
            <?php elseif ($_GET['msg'] === 'usunieto'): ?>
                <div class="alert alert-info">Klient został usunięty z bazy.</div>
            <?php endif; ?>
        <?php endif; ?>
        <div class="table-responsive">
            <table>
                <thead><tr><th>ID</th><th>Imię i Nazwisko</th><th>Email</th><th>Telefon</th><th>Adres</th><th>Akcje</th></tr></thead>
                <tbody>
                <?php if ($result && $result->num_rows > 0): ?>
                    <?php while ($row = $result->fetch_assoc()):
                        $imie    = deszyfrujDane($row['imie'], $row['id']);
                        $nazwisko = deszyfrujDane($row['nazwisko'], $row['id']);
                        $email   = deszyfrujDane($row['email'], $row['id']);
                        $telefon = deszyfrujDane($row['telefon'], $row['id']);
                        $adres   = deszyfrujDane($row['adres'], $row['id']);
                        $pokazane = isset($_SESSION['pokazane_id']) && in_array($row['id'], $_SESSION['pokazane_id']);
                        $btn_text = $pokazane ? "Ukryj" : "Pokaż";
                    ?>
                    <tr>
                        <td>#<?= $row['id'] ?></td>
                        <td><strong><?= htmlspecialchars($imie . ' ' . $nazwisko) ?></strong></td>
                        <td><?= htmlspecialchars($email) ?></td>
                        <td><?= htmlspecialchars($telefon ?? '-') ?></td>
                        <td><small><?= htmlspecialchars($adres ?? '-') ?></small></td>
                        <td class="actions-cell">
                            <a href="klienci.php?action=edytuj&id=<?= $row['id'] ?>" class="btn btn-primary btn-sm">Edytuj</a>
                            <a href="klienci.php?action=pokaz&id=<?= $row['id'] ?>" class="btn btn-outline btn-sm"><?= $btn_text ?></a>
                            <a href="klienci.php?action=usun&id=<?= $row['id'] ?>" onclick="return confirm('Czy na pewno chcesz usunąć tego klienta oraz wszystkie jego zamówienia?');" class="btn btn-danger btn-sm">Usuń</a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr><td colspan="6" style="text-align:center;">Brak klientów w bazie.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

<?php elseif (in_array($action, ['dodaj', 'edytuj'])): ?>

    <div class="topbar">
        <h2><?= $action === 'dodaj' ? 'Dodawanie nowego klienta' : 'Edycja: ' . htmlspecialchars(($klient['imie'] ?? '') . ' ' . ($klient['nazwisko'] ?? '')) ?></h2>
        <a href="klienci.php" class="btn btn-outline"><?= $action === 'dodaj' ? 'Powrót do listy' : 'Anuluj i wróć' ?></a>
    </div>

    <div class="card" style="max-width:600px;margin:0 auto;">
        <?php if ($blad): ?>
            <div class="alert alert-error"><?= htmlspecialchars($blad) ?></div>
        <?php endif; ?>
        <form method="POST" action="">
            <div style="display:flex;gap:1rem;">
                <div class="form-group" style="flex:1;">
                    <label for="imie">Imię *</label>
                    <input type="text" id="imie" name="imie" required value="<?= htmlspecialchars($klient['imie'] ?? ($_POST['imie'] ?? '')) ?>">
                </div>
                <div class="form-group" style="flex:1;">
                    <label for="nazwisko">Nazwisko *</label>
                    <input type="text" id="nazwisko" name="nazwisko" required value="<?= htmlspecialchars($klient['nazwisko'] ?? ($_POST['nazwisko'] ?? '')) ?>">
                </div>
            </div>
            <div style="display:flex;gap:1rem;">
                <div class="form-group" style="flex:1;">
                    <label for="email">Adres email *</label>
                    <input type="email" id="email" name="email" required value="<?= htmlspecialchars($klient['email'] ?? ($_POST['email'] ?? '')) ?>" style="width:100%;padding:0.75rem;border:1px solid var(--border-color);border-radius:6px;font-size:1rem;">
                </div>
                <div class="form-group" style="flex:1;">
                    <label for="telefon">Telefon (opcjonalnie)</label>
                    <input type="text" id="telefon" name="telefon" value="<?= htmlspecialchars($klient['telefon'] ?? ($_POST['telefon'] ?? '')) ?>">
                </div>
            </div>
            <div class="form-group">
                <label for="adres">Adres zamieszkania / do wysyłki (opcjonalnie)</label>
                <textarea id="adres" name="adres"><?= htmlspecialchars($klient['adres'] ?? ($_POST['adres'] ?? '')) ?></textarea>
            </div>
            <button type="submit" class="btn <?= $action === 'dodaj' ? 'btn-success' : 'btn-primary' ?> btn-block">
                <?= $action === 'dodaj' ? 'Zapisz klienta w bazie' : 'Zapisz zmiany' ?>
            </button>
        </form>
    </div>

<?php endif; ?>

</div>
</body>
</html>
