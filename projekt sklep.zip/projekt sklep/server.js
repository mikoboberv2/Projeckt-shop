const express = require('express');
const { createProxyMiddleware } = require('http-proxy-middleware');
const { spawn } = require('child_process');
const path = require('path');

// Skonfigurowane na podstawie podanej przez Ciebie ścieżki:
const PHP_PATH = 'C:\\php-8.5.4-nts-Win32-vs17-x64\\php.exe';
const PHP_PORT = 8000;
const NODE_PORT = 3000;

console.log(`[Start] Uruchamianie wbudowanego serwera PHP (${PHP_PATH}) na porcie ${PHP_PORT}...`);

// Uruchamiamy PHP w tle (odpowiednik wpisania komendy "php -S 127.0.0.1:8000" w terminalu)
const phpServer = spawn(PHP_PATH, ['-S', `127.0.0.1:${PHP_PORT}`, '-t', __dirname]);

// Zrzucanie logów PHP do konsoli Node'a
phpServer.stdout.on('data', Buffer.prototype.toString); // PHP rzuca mało rzeczy na stdout
phpServer.stderr.on('data', (data) => console.log(`[PHP Log]: ${data.toString().trim()}`));
phpServer.on('close', (code) => console.log(`[PHP]: Serwer zatrzymany z kodem ${code}`));
phpServer.on('error', (err) => {
    console.error(`[BŁĄD PHP]: Nie udało się uruchomić PHP! Sprawdź ścieżkę do php.exe.`);
    console.error(err.message);
});

// Aplikacja Express (Nasz Node.js serwer)
const app = express();

// Konfigurujemy proxy - cały ruch z przeglądarki na porcie 3000, 
// idzie bezpośrednio do wbudowanego serwera PHP na porcie 8000
app.use('/', createProxyMiddleware({
    target: `http://127.0.0.1:${PHP_PORT}`,
    changeOrigin: true,
}));

// Wystawienie serwera
app.listen(NODE_PORT, () => {
    console.log('=============================================');
    console.log(`🚀 Serwer Node.js uruchomiony pomyślnie!`);
    console.log(`✅ Zastępuje on funkcjonalność XAMPP-a.`);
    console.log(`🌐 Otwórz stronę w przeglądarce: http://localhost:${NODE_PORT}`);
    console.log('=============================================');
});

// Ważne: Zakończenie procesu PHP, gdy tylko wyłączymy serwer Node.js (np. Ctrl+C)
process.on('SIGINT', () => {
    console.log('\n[Zamykanie] Zatrzymywanie serwera PHP i wyłączanie proxy...');
    phpServer.kill();
    process.exit();
});
process.on('exit', () => phpServer.kill());
