<?php
require_once 'config.php';
sprawdzLogowanie();

$action = $_GET['action'] ?? 'lista';
$blad = '';

function formatStatus($status)
{
    switch ($status) {
        case 'nowe':       return '<span class="stock-badge stock-low" style="background:#e7f5ff;color:#1864ab;">Nowe</span>';
        case 'w trakcie':  return '<span class="stock-badge stock-low" style="background:#fff3bf;color:#e67700;">W trakcie</span>';
        case 'wysłane':    return '<span class="stock-badge stock-ok" style="background:#d3f9d8;color:#2b8a3e;">Wysłane</span>';
        case 'zakończone': return '<span class="stock-badge stock-ok">Zakończone</span>';
        case 'anulowane':  return '<span class="stock-badge stock-low">Anulowane</span>';
        default:           return htmlspecialchars($status);
    }
}

// ── AKCJE PRZEKIEROWANIA ───────────────────────────────────────────────────

if ($action === 'usun' && isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id = (int)$_GET['id'];
    $stmt = $conn->prepare("DELETE FROM zamowienia WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute()
        ? header("Location: zamowienia.php?msg=usunieto")
        : die("Błąd podczas usuwania: " . $conn->error);
    $stmt->close();
    exit;
}

// ── FORMULARZ DODAJ ────────────────────────────────────────────────────────

if ($action === 'dodaj') {
    $klienci_res = $conn->query("SELECT id, imie, nazwisko FROM klienci ORDER BY nazwisko ASC");
    $produkty_res = $conn->query("SELECT id, nazwa, cena, ilosc FROM produkty ORDER BY nazwa ASC");

    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        $klient_id  = (int)$_POST['klient_id'];
        $produkt_id = (int)$_POST['produkt_id'];
        $ilosc      = (int)$_POST['ilosc'];
        $status     = $_POST['status'];

        if ($klient_id > 0 && $produkt_id > 0 && $ilosc > 0) {
            $stmt_prod = $conn->prepare("SELECT cena, ilosc AS stan FROM produkty WHERE id = ?");
            $stmt_prod->bind_param("i", $produkt_id);
            $stmt_prod->execute();
            $res_prod = $stmt_prod->get_result();
            if ($res_prod->num_rows == 1) {
                $prod = $res_prod->fetch_assoc();
                if ($prod['stan'] >= $ilosc) {
                    $kwota = $prod['cena'] * $ilosc;
                    $stmt = $conn->prepare("INSERT INTO zamowienia (klient_id, produkt_id, ilosc, kwota, status) VALUES (?, ?, ?, ?, ?)");
                    $stmt->bind_param("iiids", $klient_id, $produkt_id, $ilosc, $kwota, $status);
                    if ($stmt->execute()) {
                        $upd = $conn->prepare("UPDATE produkty SET ilosc = ilosc - ? WHERE id = ?");
                        $upd->bind_param("ii", $ilosc, $produkt_id);
                        $upd->execute(); $upd->close();
                        $stmt->close(); $stmt_prod->close();
                        header("Location: zamowienia.php?msg=dodano"); exit;
                    } else {
                        $blad = "Błąd bazy danych: " . $conn->error;
                    }
                    $stmt->close();
                } else {
                    $blad = "Błąd: Przekroczono stan magazynowy! Dostępnych: " . $prod['stan'];
                }
            } else {
                $blad = "Wybrany produkt nie istnieje.";
            }
            $stmt_prod->close();
        } else {
            $blad = "Wybierz klienta, produkt oraz podaj prawidłową ilość.";
        }
    }
}

// ── FORMULARZ ZMIEŃ STATUS ─────────────────────────────────────────────────

$zamowienie = null;
if ($action === 'status') {
    if (!isset($_GET['id']) || !is_numeric($_GET['id'])) { header("Location: zamowienia.php"); exit; }
    $id = (int)$_GET['id'];
    $stmt = $conn->prepare("SELECT z.id, z.status, k.id AS klient_id, k.imie, k.nazwisko, p.nazwa FROM zamowienia z JOIN klienci k ON z.klient_id = k.id JOIN produkty p ON z.produkt_id = p.id WHERE z.id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute();
    $result = $stmt->get_result();
    if ($result->num_rows === 0) { header("Location: zamowienia.php"); exit; }
    $zamowienie = $result->fetch_assoc();
    $stmt->close();

    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        $nowy_status = $_POST['status'];
        $upd = $conn->prepare("UPDATE zamowienia SET status=? WHERE id=?");
        $upd->bind_param("si", $nowy_status, $id);
        if ($upd->execute()) {
            $upd->close();
            header("Location: zamowienia.php?msg=zmieniono"); exit;
        } else {
            $blad = "Błąd zapisu w bazie: " . $conn->error;
        }
        $upd->close();
    }
}

// ── LISTA ZAMÓWIEŃ ─────────────────────────────────────────────────────────

if ($action === 'lista') {
    $result = $conn->query("SELECT z.id AS zamowienie_id, z.ilosc, z.kwota, z.status, z.data_zamowienia, k.id AS klient_id, k.imie, k.nazwisko, p.nazwa AS produkt_nazwa FROM zamowienia z JOIN klienci k ON z.klient_id = k.id JOIN produkty p ON z.produkt_id = p.id ORDER BY z.id DESC");
}
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>
        <?= $action === 'dodaj' ? 'Utwórz zamówienie' : ($action === 'status' ? 'Zmień status' : 'Zamówienia - Panel Administracyjny') ?>
    </title>
    <link rel="stylesheet" href="style.css">
    <?php if (in_array($action, ['dodaj', 'status'])): ?>
    <style>select { width:100%; padding:0.75rem; border:1px solid var(--border-color); border-radius:6px; font-size:1rem; font-family:inherit; background-color:white; }</style>
    <?php endif; ?>
</head>
<body>
<?php renderNeonBg(); ?>
<div class="container">
    <?php renderNav('zamowienia'); ?>

<?php if ($action === 'lista'): ?>

    <div class="topbar">
        <h2>Wszystkie zamówienia</h2>
        <div class="topbar-actions">
            <a href="zamowienia.php?action=dodaj" class="btn btn-success">+ Dodaj zamówienie</a>
            <a href="login.php?action=logout" class="btn btn-outline">Wyloguj się</a>
        </div>
    </div>

    <div class="card">
        <?php if (isset($_GET['msg'])): ?>
            <?php if ($_GET['msg'] === 'dodano'): ?>
                <div class="alert alert-success">Zamówienie zostało utworzone!</div>
            <?php elseif ($_GET['msg'] === 'zmieniono'): ?>
                <div class="alert alert-success">Status zamówienia został zaktualizowany!</div>
            <?php elseif ($_GET['msg'] === 'usunieto'): ?>
                <div class="alert alert-info">Zamówienie zostało usunięte z bazy.</div>
            <?php endif; ?>
        <?php endif; ?>
        <div class="table-responsive">
            <table>
                <thead><tr><th>Numer</th><th>Data</th><th>Klient</th><th>Produkt</th><th>Ilość / Kwota</th><th>Status</th><th>Akcje</th></tr></thead>
                <tbody>
                <?php if ($result && $result->num_rows > 0): ?>
                    <?php while ($row = $result->fetch_assoc()):
                        $imie    = deszyfrujDane($row['imie'], $row['klient_id']);
                        $nazwisko = deszyfrujDane($row['nazwisko'], $row['klient_id']);
                    ?>
                    <tr>
                        <td><strong>#<?= $row['zamowienie_id'] ?></strong></td>
                        <td><small><?= date('d.m.Y H:i', strtotime($row['data_zamowienia'])) ?></small></td>
                        <td><?= htmlspecialchars($imie . ' ' . $nazwisko) ?></td>
                        <td><?= htmlspecialchars($row['produkt_nazwa']) ?></td>
                        <td><?= $row['ilosc'] ?> szt.<br><strong style="color:var(--success-color);"><?= number_format($row['kwota'], 2, ',', ' ') ?> zł</strong></td>
                        <td><?= formatStatus($row['status']) ?></td>
                        <td class="actions-cell">
                            <a href="zamowienia.php?action=status&id=<?= $row['zamowienie_id'] ?>" class="btn btn-primary btn-sm">Edycja statusu</a>
                            <a href="zamowienia.php?action=usun&id=<?= $row['zamowienie_id'] ?>" onclick="return confirm('Czy usunąć to zlecenie?');" class="btn btn-danger btn-sm">Usuń</a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr><td colspan="7" style="text-align:center;">Brak historii zamówień.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

<?php elseif ($action === 'dodaj'): ?>

    <div class="topbar">
        <h2>Ręczne tworzenie zamówienia</h2>
        <a href="zamowienia.php" class="btn btn-outline">Powrót do listy</a>
    </div>

    <div class="card" style="max-width:600px;margin:0 auto;">
        <?php if ($blad): ?><div class="alert alert-error"><?= htmlspecialchars($blad) ?></div><?php endif; ?>
        <form method="POST" action="">
            <div class="form-group">
                <label for="klient_id">Klient dokonujący zakupu *</label>
                <select id="klient_id" name="klient_id" required>
                    <option value="">-- Wybierz klienta z bazy --</option>
                    <?php while ($k = $klienci_res->fetch_assoc()):
                        $imie    = deszyfrujDane($k['imie'], $k['id']);
                        $nazwisko = deszyfrujDane($k['nazwisko'], $k['id']); ?>
                        <option value="<?= $k['id'] ?>"><?= htmlspecialchars($nazwisko . ' ' . $imie) ?></option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div class="form-group">
                <label for="produkt_id">Wybór produktu *</label>
                <select id="produkt_id" name="produkt_id" required>
                    <option value="">-- Wybierz produkt --</option>
                    <?php while ($p = $produkty_res->fetch_assoc()): ?>
                        <option value="<?= $p['id'] ?>" <?= $p['ilosc'] == 0 ? 'disabled' : '' ?>><?= htmlspecialchars($p['nazwa']) ?> (<?= number_format($p['cena'], 2, ',', ' ') ?> zł) - Stan: <?= $p['ilosc'] ?> szt.</option>
                    <?php endwhile; ?>
                </select>
            </div>
            <div style="display:flex;gap:1rem;">
                <div class="form-group" style="flex:1;">
                    <label for="ilosc">Ilość sztuk *</label>
                    <input type="number" min="1" id="ilosc" name="ilosc" value="1" required>
                </div>
                <div class="form-group" style="flex:1;">
                    <label for="status">Początkowy status</label>
                    <select id="status" name="status">
                        <option value="nowe" selected>Nowe</option>
                        <option value="w trakcie">W trakcie</option>
                        <option value="zakończone">Zakończone</option>
                    </select>
                </div>
            </div>
            <button type="submit" class="btn btn-success btn-block">Utwórz zamówienie</button>
        </form>
    </div>

<?php elseif ($action === 'status' && $zamowienie): ?>

    <div class="topbar">
        <h2>Edycja zamówienia #<?= $zamowienie['id'] ?></h2>
        <a href="zamowienia.php" class="btn btn-outline">Anuluj i wróć</a>
    </div>

    <div class="card" style="max-width:600px;margin:0 auto;">
        <?php if ($blad): ?><div class="alert alert-error"><?= htmlspecialchars($blad) ?></div><?php endif; ?>
        <?php
            $imie    = deszyfrujDane($zamowienie['imie'], $zamowienie['klient_id']);
            $nazwisko = deszyfrujDane($zamowienie['nazwisko'], $zamowienie['klient_id']);
        ?>
        <p style="margin-bottom:20px;">
            <strong>Klient:</strong> <?= htmlspecialchars($imie . ' ' . $nazwisko) ?><br>
            <strong>Zakup:</strong> <?= htmlspecialchars($zamowienie['nazwa']) ?>
        </p>
        <form method="POST" action="">
            <div class="form-group">
                <label for="status">Obecny status zamówienia</label>
                <select id="status" name="status">
                    <?php foreach (['nowe' => 'Nowe', 'w trakcie' => 'W trakcie', 'wysłane' => 'Wysłane', 'zakończone' => 'Zakończone', 'anulowane' => 'Anulowane'] as $val => $label): ?>
                        <option value="<?= $val ?>" <?= $zamowienie['status'] === $val ? 'selected' : '' ?>><?= $label ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <button type="submit" class="btn btn-primary btn-block">Aktualizuj status</button>
        </form>
    </div>

<?php endif; ?>

</div>
</body>
</html>
