<?php
require_once 'config.php';
sprawdzAdmin();

$action = $_GET['action'] ?? 'lista';
$blad = '';
$msg = '';

if ($action === 'usun' && isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id = (int)$_GET['id'];
    if ($id === $_SESSION['id'] ?? 0) {
        $blad = 'Nie można usunąć aktualnie zalogowanego użytkownika.';
    } else {
        $stmt = $conn->prepare("DELETE FROM administratorzy WHERE id = ?");
        $stmt->bind_param("i", $id);
        if ($stmt->execute()) {
            $msg = 'Konto zostało usunięte.';
        } else {
            $blad = 'Błąd podczas usuwania konta: ' . $conn->error;
        }
        $stmt->close();
    }
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login = trim($_POST['login']);
    $haslo = trim($_POST['haslo']);
    $typ_uprawnien = isset($_POST['typ_uprawnien']) && $_POST['typ_uprawnien'] == 1 ? 1 : 0;

    if ($login === '' || $haslo === '') {
        $blad = 'Podaj login i hasło dla nowego konta.';
    } else {
        $stmt = $conn->prepare("SELECT id FROM administratorzy WHERE login = ? LIMIT 1");
        $stmt->bind_param("s", $login);
        $stmt->execute();
        $stmt->store_result();
        if ($stmt->num_rows > 0) {
            $blad = 'Użytkownik o takim loginie już istnieje.';
            $stmt->close();
        } else {
            $stmt->close();
            $hash = password_hash($haslo, PASSWORD_DEFAULT);
            $stmt = $conn->prepare("INSERT INTO administratorzy (login, haslo, typ_uprawnien) VALUES (?, ?, ?)");
            $stmt->bind_param("ssi", $login, $hash, $typ_uprawnien);
            if ($stmt->execute()) {
                $msg = 'Nowe konto zostało utworzone.';
            } else {
                $blad = 'Błąd podczas tworzenia konta: ' . $conn->error;
            }
            $stmt->close();
        }
    }
}

$result = $conn->query("SELECT id, login, typ_uprawnien FROM administratorzy ORDER BY id DESC");
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Pracownicy - Panel Administracyjny</title>
    <link rel="stylesheet" href="style.css?v=<?php echo filemtime('style.css'); ?>">
</head>
<body>
<?php renderNeonBg(); ?>
<div class="container">
    <?php renderNav('pracownicy'); ?>

    <div class="topbar">
        <h2>Pracownicy</h2>
        <div class="topbar-actions">
            <a href="login.php?action=logout" class="btn btn-outline">Wyloguj się</a>
        </div>
    </div>

    <?php if ($msg): ?>
        <div class="alert alert-success"><?= htmlspecialchars($msg) ?></div>
    <?php endif; ?>
    <?php if ($blad): ?>
        <div class="alert alert-error"><?= htmlspecialchars($blad) ?></div>
    <?php endif; ?>

    <div class="card">
        <h3>Lista kont</h3>
        <div class="table-responsive">
            <table>
                <thead><tr><th>ID</th><th>Login</th><th>Typ uprawnień</th><th>Akcje</th></tr></thead>
                <tbody>
                <?php if ($result && $result->num_rows > 0): ?>
                    <?php while ($row = $result->fetch_assoc()): ?>
                        <tr>
                            <td>#<?= $row['id'] ?></td>
                            <td><?= htmlspecialchars($row['login']) ?></td>
                            <td><?= $row['typ_uprawnien'] == 1 ? 'Administrator' : 'Pracownik' ?></td>
                            <td class="actions-cell">
                                <?php if ($row['login'] !== $_SESSION['login']): ?>
                                    <a href="pracownicy.php?action=usun&id=<?= $row['id'] ?>" onclick="return confirm('Czy na pewno chcesz usunąć to konto?');" class="btn btn-danger btn-sm">Usuń</a>
                                <?php else: ?>
                                    <span class="btn btn-outline btn-sm" style="cursor:default; opacity:0.7;">Twoje konto</span>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr><td colspan="4" style="text-align:center;">Brak kont w systemie.</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

    <div class="card" style="margin-top:1.5rem;">
        <h3>Dodaj nowe konto</h3>
        <form method="POST" action="pracownicy.php">
            <div class="form-group">
                <label for="login">Login *</label>
                <input type="text" id="login" name="login" required>
            </div>
            <div class="form-group">
                <label for="haslo">Hasło *</label>
                <input type="password" id="haslo" name="haslo" required>
            </div>
            <div class="form-group">
                <label for="typ_uprawnien">Typ uprawnień</label>
                <select id="typ_uprawnien" name="typ_uprawnien">
                    <option value="0">Pracownik</option>
                    <option value="1">Administrator</option>
                </select>
            </div>
            <button type="submit" class="btn btn-success btn-block">Utwórz konto</button>
        </form>
    </div>
</div>
</body>
</html>
