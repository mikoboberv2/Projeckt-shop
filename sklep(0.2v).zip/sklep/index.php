<?php
require_once 'config.php';
sprawdzLogowanie();
if (!isset($_SESSION['typ_uprawnien']) || $_SESSION['typ_uprawnien'] != 1) {
    header('Location: zamowienia.php');
    exit;
}

function parseDecimal($value) {
    $value = trim($value);
    if ($value === '') return null;
    $value = str_replace([' ', "\u{00A0}"], '', $value); // usuń spacje i nbsp
    $value = str_replace(',', '.', $value);
    return is_numeric($value) ? (float)$value : null;
}

$action = $_GET['action'] ?? 'lista';
$blad = '';

// ── AKCJE (POST/redirect) ──────────────────────────────────────────────────

if ($action === 'usun' && isset($_GET['id']) && is_numeric($_GET['id'])) {
    $id = (int)$_GET['id'];
    $stmt = $conn->prepare("DELETE FROM produkty WHERE id = ?");
    $stmt->bind_param("i", $id);
    $stmt->execute() 
        ? header("Location: index.php?msg=usunieto") 
        : die("Błąd podczas usuwania: " . $conn->error);
    $stmt->close();
    exit;
}

if ($action === 'pokaz' && isset($_GET['id']) && is_numeric($_GET['id'])) {
    if (!isset($_SESSION['pokazane_id'])) $_SESSION['pokazane_id'] = [];
    $id = (int)$_GET['id'];
    if (in_array($id, $_SESSION['pokazane_id'])) {
        $_SESSION['pokazane_id'] = array_diff($_SESSION['pokazane_id'], [$id]);
    } else {
        $_SESSION['pokazane_id'][] = $id;
    }
    header("Location: " . ($_SERVER['HTTP_REFERER'] ?? 'index.php'));
    exit;
}

// ── FORMULARZ DODAJ / EDYTUJ ───────────────────────────────────────────────

$produkt = null;
if (in_array($action, ['dodaj', 'edytuj'])) {
    if ($action === 'edytuj') {
        if (!isset($_GET['id']) || !is_numeric($_GET['id'])) { header("Location: index.php"); exit; }
        $id = (int)$_GET['id'];
        $stmt = $conn->prepare("SELECT * FROM produkty WHERE id = ?");
        $stmt->bind_param("i", $id);
        $stmt->execute();
        $result = $stmt->get_result();
        if ($result->num_rows === 0) { header("Location: index.php"); exit; }
        $produkt = $result->fetch_assoc();
        $stmt->close();
    }

    if ($_SERVER["REQUEST_METHOD"] === "POST") {
        $nazwa       = trim($_POST['nazwa']);
        $opis        = trim($_POST['opis']);
        $cena        = parseDecimal($_POST['cena'] ?? '');
        $ilosc       = (int)$_POST['ilosc'];
        $zdjecie_url = trim($_POST['zdjecie_url']);

        if (!empty($nazwa) && $cena !== null && $cena > 0 && $ilosc >= 0) {
            if ($action === 'dodaj') {
                $stmt = $conn->prepare("INSERT INTO produkty (nazwa, opis, cena, ilosc, zdjecie_url) VALUES (?, ?, ?, ?, ?)");
                $stmt->bind_param("ssdis", $nazwa, $opis, $cena, $ilosc, $zdjecie_url);
                $redirect = "index.php?msg=dodano";
            } else {
                $stmt = $conn->prepare("UPDATE produkty SET nazwa=?, opis=?, cena=?, ilosc=?, zdjecie_url=? WHERE id=?");
                $stmt->bind_param("ssdisi", $nazwa, $opis, $cena, $ilosc, $zdjecie_url, $id);
                $redirect = "index.php?msg=edytowano";
            }
            if ($stmt->execute()) {
                $stmt->close();
                header("Location: $redirect");
                exit;
            } else {
                $blad = "Błąd bazy danych: " . $conn->error;
            }
            $stmt->close();
        } else {
            $blad = "Podaj poprawną nazwę, cenę (>0) i ilość (≥0).";
        }
    }
}

// ── LISTA PRODUKTÓW ────────────────────────────────────────────────────────

if ($action === 'lista') {
    $result = $conn->query("SELECT * FROM produkty ORDER BY id DESC");
}
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>
        <?= $action === 'dodaj' ? 'Dodaj produkt' : ($action === 'edytuj' ? 'Edytuj produkt' : 'Sklep - Panel Administracyjny') ?>
    </title>
    <link rel="stylesheet" href="style.css?v=<?php echo filemtime('style.css'); ?>">
</head>
<body>
<?php renderNeonBg(); ?>
<div class="container">
    <?php renderNav('produkty'); ?>

<?php if ($action === 'lista'): ?>

    <div class="topbar">
        <h2>Towary</h2>
        <div class="topbar-actions">
            <a href="index.php?action=dodaj" class="btn btn-success">+ Dodaj produkt</a>
            <a href="login.php?action=logout" class="btn btn-outline">Wyloguj się</a>
        </div>
    </div>

    <div class="card">
        <?php if (isset($_GET['msg'])): ?>
            <?php if ($_GET['msg'] === 'dodano'): ?>
                <div class="alert alert-success">Produkt został pomyślnie dodany!</div>
            <?php elseif ($_GET['msg'] === 'edytowano'): ?>
                <div class="alert alert-success">Zmiany zostały zapisane!</div>
            <?php elseif ($_GET['msg'] === 'usunieto'): ?>
                <div class="alert alert-info">Produkt został usunięty z bazy.</div>
            <?php endif; ?>
        <?php endif; ?>
        <div class="table-responsive">
            <table>
                <thead><tr><th>ID</th><th>Zdjęcie</th><th>Nazwa i Opis</th><th>Cena</th><th>Stan</th><th>Akcje</th></tr></thead>
                <tbody>
                <?php if ($result && $result->num_rows > 0): ?>
                    <?php while ($row = $result->fetch_assoc()): ?>
                    <tr>
                        <td>#<?= $row['id'] ?></td>
                        <td>
                            <?php if (!empty($row['zdjecie_url'])): ?>
                                <img src="<?= htmlspecialchars($row['zdjecie_url']) ?>" alt="Zdjecie" class="prod-img">
                            <?php else: ?>
                                <div style="width:50px;height:50px;background:#eee;border-radius:6px;"></div>
                            <?php endif; ?>
                        </td>
                        <td>
                            <strong><?= htmlspecialchars($row['nazwa']) ?></strong><br>
                            <small style="color:#6c757d;"><?= htmlspecialchars(mb_substr($row['opis'], 0, 50)) ?>...</small>
                        </td>
                        <td class="price-tag">
                            <?php
                                if (is_numeric($row['cena'])) {
                                    echo number_format((float)$row['cena'], 2, ',', ' ') . ' zł';
                                } else {
                                    echo '<span style="color:#dc3545;">Brak ceny</span>';
                                }
                            ?>
                        </td>
                        <td>
                            <?php if ($row['ilosc'] > 10): ?>
                                <span class="stock-badge stock-ok"><?= $row['ilosc'] ?> szt.</span>
                            <?php else: ?>
                                <span class="stock-badge stock-low"><?= $row['ilosc'] ?> szt.</span>
                            <?php endif; ?>
                        </td>
                        <td class="actions-cell">
                            <a href="index.php?action=edytuj&id=<?= $row['id'] ?>" class="btn btn-primary btn-sm">Edytuj</a>
                            <a href="index.php?action=usun&id=<?= $row['id'] ?>" onclick="return confirm('Czy na pewno chcesz usunąć ten produkt?');" class="btn btn-danger btn-sm">Usuń</a>
                        </td>
                    </tr>
                    <?php endwhile; ?>
                <?php else: ?>
                    <tr><td colspan="6" style="text-align:center;">Brak produktów w bazie. Dodaj swój pierwszy produkt!</td></tr>
                <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>

<?php elseif (in_array($action, ['dodaj', 'edytuj'])): ?>

    <div class="topbar">
        <h2><?= $action === 'dodaj' ? 'Dodawanie nowego produktu' : 'Edycja: ' . htmlspecialchars($produkt['nazwa']) ?></h2>
        <a href="index.php" class="btn btn-outline"><?= $action === 'dodaj' ? 'Powrót do listy' : 'Anuluj i wróć' ?></a>
    </div>

    <div class="card" style="max-width:600px;margin:0 auto;">
        <?php if ($blad): ?>
            <div class="alert alert-error"><?= htmlspecialchars($blad) ?></div>
        <?php endif; ?>
        <form method="POST" action="">
            <div class="form-group">
                <label for="nazwa">Nazwa produktu *</label>
                <input type="text" id="nazwa" name="nazwa" required value="<?= htmlspecialchars($produkt['nazwa'] ?? ($_POST['nazwa'] ?? '')) ?>">
            </div>
            <div class="form-group">
                <label for="opis">Opis (opcjonalnie)</label>
                <textarea id="opis" name="opis"><?= htmlspecialchars($produkt['opis'] ?? ($_POST['opis'] ?? '')) ?></textarea>
            </div>
            <div style="display:flex;gap:1rem;">
                <div class="form-group" style="flex:1;">
                    <label for="cena">Cena (PLN) *</label>
                    <input type="number" step="0.01" min="0.01" id="cena" name="cena" required value="<?= htmlspecialchars($produkt['cena'] ?? ($_POST['cena'] ?? '')) ?>">
                </div>
                <div class="form-group" style="flex:1;">
                    <label for="ilosc">Ilość w magazynie *</label>
                    <input type="number" min="0" id="ilosc" name="ilosc" required value="<?= htmlspecialchars($produkt['ilosc'] ?? ($_POST['ilosc'] ?? '0')) ?>">
                </div>
            </div>
            <div class="form-group">
                <label for="zdjecie_url">Link URL do zdjęcia (opcjonalnie)</label>
                <input type="url" id="zdjecie_url" name="zdjecie_url" placeholder="http://..." value="<?= htmlspecialchars($produkt['zdjecie_url'] ?? ($_POST['zdjecie_url'] ?? '')) ?>">
            </div>
            <button type="submit" class="btn <?= $action === 'dodaj' ? 'btn-success' : 'btn-primary' ?> btn-block">
                <?= $action === 'dodaj' ? 'Zapisz produkt w bazie' : 'Zapisz zmiany' ?>
            </button>
        </form>
    </div>

<?php endif; ?>

</div>
</body>
</html>
