<?php
session_start();

// Obsługa wylogowania
if (isset($_GET['action']) && $_GET['action'] === 'logout') {
    session_unset();
    session_destroy();
    header("Location: login.php");
    exit;
}

require_once 'config.php';

if (isset($_SESSION['zalogowany']) && $_SESSION['zalogowany'] === true) {
    header("Location: index.php");
    exit;
}

$blad = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $login = trim($_POST['login']);
    $haslo = trim($_POST['haslo']);

    if (!empty($login) && !empty($haslo)) {
        $stmt = $conn->prepare("SELECT id FROM administratorzy WHERE login = ? AND haslo = ? LIMIT 1");
        $stmt->bind_param("ss", $login, $haslo);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows == 1) {
            $_SESSION['zalogowany'] = true;
            $_SESSION['login'] = $login;
            header("Location: index.php");
            exit;
        } else {
            $blad = "Nieprawidłowy login lub hasło!";
        }
        $stmt->close();
    } else {
        $blad = "Wypełnij wszystkie pola!";
    }
}
?>
<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logowanie do panelu</title>
    <link rel="stylesheet" href="style.css?v=<?php echo filemtime('style.css'); ?>">
</head>
<body class="login-body">
<?php renderNeonBg(); ?>
    <div class="login-container">
        <h2>Panel Administracyjny</h2>
        <p class="subtitle">Zaloguj się do systemu sklepu</p>

        <?php if ($blad): ?>
            <div class="alert alert-error"><?= htmlspecialchars($blad) ?></div>
        <?php endif; ?>

        <form method="POST" action="">
            <div class="form-group">
                <label for="login">Login administratora</label>
                <input type="text" id="login" name="login" placeholder="Wpisz 'admin'" required>
            </div>
            <div class="form-group">
                <label for="haslo">Hasło</label>
                <input type="password" id="haslo" name="haslo" placeholder="Wpisz 'admin123'" required>
            </div>
            <button type="submit" class="btn btn-primary btn-block">Zaloguj się</button>
        </form>
    </div>
</body>
</html>
