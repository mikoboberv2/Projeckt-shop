<?php
$host = 'localhost';
$db_user = 'user';
$db_password = 'miko0205';
$db_name = 'sklep_db';

$conn = new mysqli($host, $db_user, $db_password, $db_name);

if ($conn->connect_error) {
    die("Błąd połączenia z bazą danych: " . $conn->connect_error);
}
$conn->set_charset("utf8mb4");

// OCHRONA DANYCH - RODO (TYLKO FRONTEND)
function deszyfrujDane($tekst, $id = null)
{
    if (empty($tekst) || $tekst === '(Brak - RODO)')
        return $tekst;

    if ($id !== null && isset($_SESSION['pokazane_id']) && in_array($id, $_SESSION['pokazane_id'])) {
        return $tekst;
    }

    if (filter_var($tekst, FILTER_VALIDATE_EMAIL)) {
        $parts = explode('@', $tekst);
        $name = $parts[0];
        $domain = $parts[1];
        $maskedName = mb_substr($name, 0, 1) . str_repeat('*', max(1, mb_strlen($name) - 1));
        return $maskedName . '@' . $domain;
    }

    $first = mb_substr($tekst, 0, 1);
    $length = mb_strlen($tekst);
    if ($length <= 1)
        return $tekst;
    return $first . str_repeat('*', $length - 1);
}

function szyfrujDane($tekst)
{
    return $tekst;
}

function sprawdzLogowanie()
{
    session_start();
    if (!isset($_SESSION['zalogowany']) || $_SESSION['zalogowany'] !== true) {
        header('Location: login.php');
        exit;
    }
}

// Nawigacja główna (zastępuje nav.php)
function renderNav($aktywna = '')
{
    $strony = [
        'produkty'   => ['href' => 'index.php',     'label' => 'Towary'],
        'klienci'    => ['href' => 'klienci.php',   'label' => 'Kontrahenci'],
        'zamowienia' => ['href' => 'zamowienia.php','label' => 'Zamówienia'],
    ];
    echo '<div class="main-nav">';
    foreach ($strony as $klucz => $s) {
        $active = ($klucz === $aktywna) ? 'active' : '';
        echo '<a href="' . $s['href'] . '" class="nav-link ' . $active . '">' . $s['label'] . '</a>';
    }
    echo '</div>';
}

// Tło - nie renderuje nic
function renderNeonBg()
{
    // Pusty - nie potrzebne
}
?>